# 🚀 ExportHunter AI

**AI-Powered B2B Sales CRM for Turkish Exporters**

Türk ihracatçılar için yapay zeka destekli otomatik müşteri bulma, e-posta gönderme ve takip sistemi.

---

## 📋 Proje Özeti

**Problem:** İhracatçılar doğru müşteriyi bulamıyor, manuel iş çok fazla, takip kayboluyor.

**Çözüm:** AI ile otomatik müşteri bulma + e-posta kampanya yönetimi + akıllı takip sistemi.

---

## 🏗️ Proje Yapısı

```
exporthunter-ai/
├── frontend/              # React + TypeScript + Tailwind
│   ├── src/
│   │   ├── components/   # UI bileşenleri
│   │   ├── pages/        # Sayfa bileşenleri
│   │   ├── contexts/     # React Context (Auth vb.)
│   │   ├── hooks/        # Custom hooks
│   │   ├── services/     # API entegrasyonları
│   │   ├── types/        # TypeScript tipleri
│   │   └── utils/        # Yardımcı fonksiyonlar
│   ├── public/
│   └── package.json
│
├── backend/              # Node.js + Express + TypeScript
│   ├── src/
│   │   ├── routes/       # API route'ları
│   │   ├── controllers/  # İş mantığı
│   │   ├── models/       # MongoDB modelleri
│   │   ├── middleware/   # Express middleware
│   │   ├── services/     # Servis katmanı
│   │   │   ├── ai/       # Claude API entegrasyonu
│   │   │   ├── email/    # E-posta gönderimi
│   │   │   └── scraper/  # Web scraping
│   │   ├── utils/        # Yardımcı fonksiyonlar
│   │   └── types/        # TypeScript tipleri
│   └── package.json
│
├── shared/               # Paylaşılan tipler
│   └── types/
│
├── docker/              # Docker yapılandırması
│   ├── Dockerfile.frontend
│   ├── Dockerfile.backend
│   └── docker-compose.yml
│
├── scripts/             # Yardımcı scriptler
│   ├── setup.sh
│   └── seed-db.js
│
├── docs/                # Dokümantasyon
│   ├── API.md
│   ├── DEPLOYMENT.md
│   └── ARCHITECTURE.md
│
├── .env.example
├── .gitignore
├── package.json         # Root package.json (workspace)
└── README.md
```

---

## 🎯 Temel Özellikler (MVP)

### 1️⃣ AI Customer Discovery
- Kullanıcı ürün bilgisi girer
- AI web'de potansiyel müşterileri bulur
- E-posta adresleri otomatik tahmin edilir

### 2️⃣ Smart Email Campaign
- AI ile özelleştirilmiş e-posta yazımı
- Otomatik zamanlama ve gönderim
- A/B testing desteği

### 3️⃣ Intelligent Follow-up
- E-posta açılma/tıklama takibi
- Otomatik 2. ve 3. takip e-postaları
- AI ile cevap kategorizasyonu

### 4️⃣ CRM Dashboard
- Pipeline görünümü
- Aktivite timeline
- Raporlama ve analizler

### 5️⃣ AI Sales Assistant
- Chatbot yardımcı
- Akıllı öneriler
- Otomatik PDF oluşturma

---

## 🛠️ Teknoloji Stack'i

### Frontend
- **React 18** + **TypeScript**
- **Tailwind CSS** (Styling)
- **React Query** (Server state)
- **React Router v6** (Routing)
- **Zustand** (Global state)
- **Recharts** (Charts)
- **Radix UI** (UI primitives)

### Backend
- **Node.js 20** + **Express**
- **TypeScript**
- **MongoDB** (Database)
- **Prisma** (ORM - opsiyonel)
- **JWT** (Authentication)
- **Bull** (Queue management)
- **Redis** (Cache)

### AI & Services
- **Claude API** (Sonnet 4)
- **Web Search API** (Lead finding)
- **SendGrid/AWS SES** (Email)
- **Puppeteer** (Web scraping)

### DevOps
- **Docker** + **Docker Compose**
- **GitHub Actions** (CI/CD)
- **AWS/DigitalOcean** (Hosting)

---

## 🚀 Hızlı Başlangıç

### Gereksinimler
- Node.js 20+
- MongoDB 7+
- Redis 7+
- npm/yarn/pnpm

### Kurulum

```bash
# 1. Repoyu klonla
git clone https://github.com/yourusername/exporthunter-ai.git
cd exporthunter-ai

# 2. Environment değişkenlerini ayarla
cp .env.example .env
# .env dosyasını düzenle (API keys vb.)

# 3. Bağımlılıkları yükle
npm install

# 4. MongoDB ve Redis'i başlat (Docker ile)
docker-compose up -d mongodb redis

# 5. Veritabanını seed et
npm run db:seed

# 6. Development sunucularını başlat
npm run dev
```

### Development Sunucuları
- Frontend: http://localhost:3000
- Backend: http://localhost:3001
- API Docs: http://localhost:3001/api-docs

---

## 📦 Proje Komutları

```bash
# Root seviyede (tüm workspace)
npm run dev          # Frontend + Backend dev server
npm run build        # Production build
npm run test         # Tüm testleri çalıştır
npm run lint         # Lint tüm kod
npm run format       # Format tüm kod

# Frontend
cd frontend
npm run dev          # Development server
npm run build        # Production build
npm run test         # Frontend testleri
npm run storybook    # Storybook UI

# Backend
cd backend
npm run dev          # Development server (nodemon)
npm run build        # TypeScript compile
npm run test         # Backend testleri
npm run db:migrate   # Database migration
npm run db:seed      # Seed data
```

---

## 🔐 Environment Variables

### Backend (.env)
```env
# Server
NODE_ENV=development
PORT=3001
FRONTEND_URL=http://localhost:3000

# Database
MONGODB_URI=mongodb://localhost:27017/exporthunter
REDIS_URL=redis://localhost:6379

# JWT
JWT_SECRET=your-super-secret-jwt-key-change-this
JWT_REFRESH_SECRET=your-refresh-secret-key
JWT_EXPIRES_IN=1h
JWT_REFRESH_EXPIRES_IN=7d

# Claude API
ANTHROPIC_API_KEY=your-claude-api-key

# Email Service (SendGrid)
SENDGRID_API_KEY=your-sendgrid-api-key
EMAIL_FROM=noreply@exporthunter.ai

# Web Search (optional)
SERP_API_KEY=your-serp-api-key
```

### Frontend (.env)
```env
REACT_APP_API_URL=http://localhost:3001/api
REACT_APP_APP_NAME=ExportHunter AI
REACT_APP_ENV=development
```

---

## 📊 Database Schema

### Users
```typescript
{
  _id: ObjectId
  email: string (unique, indexed)
  name: string
  password: string (hashed)
  company: string
  role: 'user' | 'admin'
  subscription: 'free' | 'starter' | 'professional' | 'enterprise'
  emailVerified: boolean
  createdAt: Date
  updatedAt: Date
}
```

### Leads (Prospects)
```typescript
{
  _id: ObjectId
  userId: ObjectId (ref: User)
  companyName: string
  country: string
  city: string
  email: string
  phone: string
  website: string
  industry: string
  status: 'new' | 'contacted' | 'interested' | 'qualified' | 'customer' | 'rejected'
  source: 'ai-discovery' | 'manual' | 'import'
  tags: string[]
  notes: string
  aiScore: number (0-100)
  createdAt: Date
  updatedAt: Date
}
```

### EmailCampaigns
```typescript
{
  _id: ObjectId
  userId: ObjectId (ref: User)
  name: string
  subject: string
  body: string
  status: 'draft' | 'scheduled' | 'sending' | 'completed' | 'paused'
  scheduledAt: Date
  totalRecipients: number
  sentCount: number
  openedCount: number
  clickedCount: number
  repliedCount: number
  createdAt: Date
  updatedAt: Date
}
```

### EmailActivities
```typescript
{
  _id: ObjectId
  campaignId: ObjectId (ref: EmailCampaign)
  leadId: ObjectId (ref: Lead)
  status: 'sent' | 'opened' | 'clicked' | 'replied' | 'bounced' | 'failed'
  sentAt: Date
  openedAt: Date
  clickedAt: Date
  repliedAt: Date
  metadata: object
}
```

---

## 🧪 Testing

### Unit Tests
```bash
# Frontend
cd frontend && npm run test

# Backend
cd backend && npm run test
```

### E2E Tests
```bash
# Playwright
npm run test:e2e
```

### API Tests
```bash
# Postman collection
newman run postman/ExportHunter-API.postman_collection.json
```

---

## 🚢 Deployment

### Docker Production Build
```bash
# Build images
docker-compose -f docker-compose.prod.yml build

# Run containers
docker-compose -f docker-compose.prod.yml up -d

# Check logs
docker-compose logs -f
```

### Cloud Deployment (AWS)
```bash
# Deploy to AWS ECS
npm run deploy:aws

# Deploy to DigitalOcean
npm run deploy:do
```

Detaylı deployment rehberi için: [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md)

---

## 📖 API Dokümantasyonu

API dokümantasyonu Swagger/OpenAPI ile hazırlanmıştır:

- **Local:** http://localhost:3001/api-docs
- **Production:** https://api.exporthunter.ai/docs

Manuel API dokümantasyonu: [docs/API.md](docs/API.md)

---

## 🤝 Katkıda Bulunma

1. Fork edin
2. Feature branch oluşturun (`git checkout -b feature/AmazingFeature`)
3. Commit edin (`git commit -m 'Add some AmazingFeature'`)
4. Push edin (`git push origin feature/AmazingFeature`)
5. Pull Request açın

---

## 📝 Lisans

Bu proje MIT lisansı altındadır. Detaylar için [LICENSE](LICENSE) dosyasına bakın.

---

## 👥 Ekip

- **Founder/CEO:** [Your Name]
- **CTO:** [CTO Name]
- **Frontend Dev:** [Dev Name]
- **Backend Dev:** [Dev Name]

---

## 📞 İletişim

- **Email:** info@exporthunter.ai
- **Website:** https://exporthunter.ai
- **LinkedIn:** https://linkedin.com/company/exporthunter-ai
- **Twitter:** @ExportHunterAI

---

## 🎯 Roadmap

### Q1 2025
- [x] MVP geliştirme
- [x] 50 beta kullanıcı
- [ ] Product launch

### Q2 2025
- [ ] 200 ödeyici müşteri
- [ ] Çoklu dil desteği
- [ ] Mobil app

### Q3 2025
- [ ] WhatsApp entegrasyonu
- [ ] LinkedIn auto-connect
- [ ] 1,000 müşteri

### Q4 2025
- [ ] API marketplace
- [ ] White-label çözüm
- [ ] Enterprise features

---

**Made with ❤️ in Turkey 🇹🇷**
